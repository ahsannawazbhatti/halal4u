<!DOCTYPE html>
<html lang="es">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="canonical" href="https://www.halal4u.es/www.webador.pl">
        <link rel="sitemap" type="application/xml" href="https://www.halal4u.es/sitemap.xml">
        <meta property="og:title" content="Página no encontrada">
        <meta property="og:url" content="https://www.halal4u.es/www.webador.pl">
        <base href="https://www.halal4u.es/">
        <meta name="description" property="og:description" content="">
                <script nonce="bab73023f85443a8a59ed24af052cf0d">
            
            window.JOUWWEB = window.JOUWWEB || {};
            window.JOUWWEB.application = window.JOUWWEB.application || {};
            window.JOUWWEB.application = {"backends":[{"domain":"jouwweb.nl","freeDomain":"jouwweb.site"},{"domain":"webador.com","freeDomain":"webadorsite.com"},{"domain":"webador.de","freeDomain":"webadorsite.com"},{"domain":"webador.fr","freeDomain":"webadorsite.com"},{"domain":"webador.es","freeDomain":"webadorsite.com"},{"domain":"webador.it","freeDomain":"webadorsite.com"},{"domain":"jouwweb.be","freeDomain":"jouwweb.site"},{"domain":"webador.ie","freeDomain":"webadorsite.com"},{"domain":"webador.co.uk","freeDomain":"webadorsite.com"},{"domain":"webador.at","freeDomain":"webadorsite.com"},{"domain":"webador.be","freeDomain":"webadorsite.com"},{"domain":"webador.ch","freeDomain":"webadorsite.com"},{"domain":"webador.ch","freeDomain":"webadorsite.com"},{"domain":"webador.mx","freeDomain":"webadorsite.com"},{"domain":"webador.com","freeDomain":"webadorsite.com"},{"domain":"webador.dk","freeDomain":"webadorsite.com"},{"domain":"webador.se","freeDomain":"webadorsite.com"},{"domain":"webador.no","freeDomain":"webadorsite.com"},{"domain":"webador.fi","freeDomain":"webadorsite.com"},{"domain":"webador.ca","freeDomain":"webadorsite.com"},{"domain":"webador.ca","freeDomain":"webadorsite.com"},{"domain":"webador.pl","freeDomain":"webadorsite.com"},{"domain":"webador.com.au","freeDomain":"webadorsite.com"},{"domain":"webador.nz","freeDomain":"webadorsite.com"}],"editorLocale":"es-ES","editorTimezone":"Europe\/Madrid","editorLanguage":"es","analytics4TrackingId":"G-E6PZPGE4QM","analyticsDimensions":{"app_context":"404"},"backendDomain":"www.webador.es","backendShortDomain":"webador.es","backendKey":"webador-es","freeWebsiteDomain":"webadorsite.com","noSsl":false,"build":{"reference":"169afd4"},"linkHostnames":["www.jouwweb.nl","www.webador.com","www.webador.de","www.webador.fr","www.webador.es","www.webador.it","www.jouwweb.be","www.webador.ie","www.webador.co.uk","www.webador.at","www.webador.be","www.webador.ch","fr.webador.ch","www.webador.mx","es.webador.com","www.webador.dk","www.webador.se","www.webador.no","www.webador.fi","www.webador.ca","fr.webador.ca","www.webador.pl","www.webador.com.au","www.webador.nz"],"assetsUrl":"https:\/\/assets.jwwb.nl","loginUrl":"https:\/\/www.webador.es\/iniciar-sesion","publishUrl":"https:\/\/www.webador.es\/v2\/website\/6999929\/publish-proxy","adminUserOrIp":false,"currency":"EUR","hcUrl":{"add-product-variants":"https:\/\/help.webador.com\/hc\/es\/articles\/29426751649809","basic-vs-advanced-shipping":"https:\/\/help.webador.com\/hc\/es\/articles\/29426731685777","html-in-head":"https:\/\/help.webador.com\/hc\/es\/articles\/29426689990033","link-domain-name":"https:\/\/help.webador.com\/hc\/es\/articles\/29426688803345","optimize-for-mobile":"https:\/\/help.webador.com\/hc\/es\/articles\/29426707033617","seo":"https:\/\/help.webador.com\/hc\/es\/categories\/29387178511377","transfer-domain-name":"https:\/\/help.webador.com\/hc\/es\/articles\/29426715688209","website-not-secure":"https:\/\/help.webador.com\/hc\/es\/articles\/29426706659729"}};
            window.JOUWWEB.brand = {"type":"webador","name":"Webador","domain":"Webador.es","supportEmail":"soporte@webador.es"};
                    
                window.JOUWWEB = window.JOUWWEB || {};
                window.JOUWWEB.websiteRendering = {"locale":"es-ES","timezone":"Europe\/Madrid","routes":{"api\/upload\/product-field":"\/_api\/upload\/product-field","checkout\/cart":"\/cart","payment":"\/complete-order\/:publicOrderId","payment\/forward":"\/complete-order\/:publicOrderId\/forward","public-order":"\/order\/:publicOrderId","checkout\/authorize":"\/cart\/authorize\/:gateway","wishlist":"\/wishlist"}};
                                                    window.JOUWWEB.website = {"id":6999929,"locale":"es-ES","enabled":true,"title":"Halal4u","hasTitle":true,"roleOfLoggedInUser":null,"ownerLocale":"es-ES","plan":"pro","freeWebsiteDomain":"webadorsite.com","backendKey":"webador-es","currency":"EUR","defaultLocale":"es-ES","url":"https:\/\/www.halal4u.es\/","homepageSegmentId":30127583,"category":"webshop","isOffline":false,"isPublished":true,"locales":["es-ES"],"allowed":{"ads":false,"credits":true,"externalLinks":true,"slideshow":true,"customDefaultSlideshow":false,"hostedAlbums":true,"moderators":true,"mailboxQuota":1,"statisticsVisitors":true,"statisticsDetailed":true,"statisticsMonths":0,"favicon":true,"password":true,"freeDomains":0,"freeMailAccounts":1,"canUseLanguages":false,"fileUpload":true,"legacyFontSize":false,"webshop":true,"products":10,"imageText":false,"search":true,"audioUpload":true,"videoUpload":0,"allowDangerousForms":false,"allowHtmlCode":true,"mobileBar":true,"sidebar":false,"poll":false,"allowCustomForms":true,"allowBusinessListing":true,"allowCustomAnalytics":true,"allowAccountingLink":true,"digitalProducts":false,"sitemapElement":false},"mobileBar":{"enabled":true,"theme":"accent","email":{"active":true,"value":"info@halal4u.es"},"location":{"active":true,"value":"Calle Jer\u00f3nimo De Val\u00e8ncia 18, Badajoz"},"phone":{"active":true,"value":"+34634432424"},"whatsapp":{"active":true,"value":"+34634432424"},"social":{"active":false,"network":"facebook"}},"webshop":{"enabled":true,"currency":"EUR","taxEnabled":true,"taxInclusive":true,"vatDisclaimerVisible":false,"orderNotice":null,"orderConfirmation":null,"freeShipping":true,"freeShippingAmount":"250.00","shippingDisclaimerVisible":false,"pickupAllowed":false,"couponAllowed":false,"detailsPageAvailable":true,"socialMediaVisible":false,"termsPage":null,"termsPageUrl":null,"extraTerms":null,"pricingVisible":true,"orderButtonVisible":true,"checkoutRestricted":false,"shippingAdvanced":false,"shippingAdvancedBackEnd":false,"soldOutVisible":true,"backInStockNotificationEnabled":true,"canAddProducts":false,"nextOrderNumber":28,"allowedServicePoints":[],"sendcloudConfigured":false,"sendcloudFallbackPublicKey":"a3d50033a59b4a598f1d7ce7e72aafdf","taxExemptionAllowed":true,"invoiceComment":null,"emptyCartVisible":true,"minimumOrderPrice":null,"productNumbersEnabled":true,"wishlistEnabled":true,"hideTaxOnCart":true},"isTreatedAsWebshop":true};                            window.JOUWWEB.cart = {"products":[],"coupon":null,"shippingCountryCode":null,"shippingChoice":null,"breakdown":[]};                            window.JOUWWEB.scripts = ["website-rendering\/webshop"];                        window.parent.JOUWWEB.colorPalette = window.JOUWWEB.colorPalette;
        </script>
                    <meta name="robots" content="noindex,nofollow">
                <title>Página no encontrada</title>
                                            <link href="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/touch-icon-iphone.png?bust=1756555395" rel="apple-touch-icon" sizes="60x60">                                                <link href="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/touch-icon-ipad.png?bust=1756555395" rel="apple-touch-icon" sizes="76x76">                                                <link href="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/touch-icon-iphone-retina.png?bust=1756555395" rel="apple-touch-icon" sizes="120x120">                                                <link href="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/touch-icon-ipad-retina.png?bust=1756555395" rel="apple-touch-icon" sizes="152x152">                                                <link href="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/favicon.png?bust=1756555395" rel="shortcut icon">                                                <link href="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/favicon.png?bust=1756555395" rel="icon">                                        <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4995-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=1200">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4996-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=1200">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4994-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=1200">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4993-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=1200">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/f601680f-711b-4a3a-bdb3-1026c5170670-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=1200">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7536-high.webp">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_9319-high-ufffd0.webp">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7531-high-f6obcy.webp">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7532-high.webp">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_0919-high.jpg">
                    <meta property="og:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7531-high-f6obcy.webp">
                                    <meta name="twitter:card" content="summary_large_image">
                        <meta property="twitter:image" content="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4995-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=1200">
                                                    <script src="https://plausible.io/js/script.manual.js" nonce="bab73023f85443a8a59ed24af052cf0d" data-turbo-track="reload" defer data-domain="shard4.jouwweb.nl"></script>
<link rel="stylesheet" type="text/css" href="https://gfonts.jwwb.nl/css?display=fallback&amp;family=Roboto%3A400%2C700%2C400italic%2C700italic%7CMontserrat%3A400%2C700%2C400italic%2C700italic" nonce="bab73023f85443a8a59ed24af052cf0d" data-turbo-track="dynamic">
<script src="https://assets.jwwb.nl/assets/website-rendering-i18n/es-ES.js?bust=1f4cd025e9b1ee66883f" nonce="bab73023f85443a8a59ed24af052cf0d" data-turbo-track="reload" defer></script>
<script src="https://assets.jwwb.nl/assets/website-rendering/runtime.a2455a67aab510c8778e.js?bust=2b1f8035561513566faf" nonce="bab73023f85443a8a59ed24af052cf0d" data-turbo-track="reload" defer></script>
<script src="https://assets.jwwb.nl/assets/website-rendering/964.a958855da07340f5fab3.js?bust=7f40a67c5d0bee8ef59b" nonce="bab73023f85443a8a59ed24af052cf0d" data-turbo-track="reload" defer></script>
<script src="https://assets.jwwb.nl/assets/website-rendering/main.d87b2b8409e132c74c06.js?bust=86c180357cf40edf68d0" nonce="bab73023f85443a8a59ed24af052cf0d" data-turbo-track="reload" defer></script>
<link rel="preload" href="https://assets.jwwb.nl/assets/website-rendering/main.b3be791fe0ea9410a7ef.css?bust=bebe292eacb5115a15cc" as="style">
<link rel="preload" href="https://assets.jwwb.nl/assets/website-rendering/fonts/icons-website-rendering/font/website-rendering.woff2?bust=eeda4129169be2e46f13" as="font" crossorigin>
<link rel="preconnect" href="https://gfonts.jwwb.nl">
<link rel="preconnect" href="https://assets.jwwb.nl">
<link rel="stylesheet" type="text/css" href="https://assets.jwwb.nl/assets/website-rendering/main.b3be791fe0ea9410a7ef.css?bust=bebe292eacb5115a15cc" nonce="bab73023f85443a8a59ed24af052cf0d" data-turbo-track="dynamic">
<link rel="stylesheet" type="text/css" href="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/style.css?bust=1789486274" nonce="bab73023f85443a8a59ed24af052cf0d" data-turbo-track="dynamic" id="jw-website-stylesheet">    </head>
    <body
        id="top"
        class="jw-is-no-slideshow jw-header-is-image-text jw-is-segment-custom jw-is-frontend jw-is-no-sidebar jw-is-messagebar jw-is-no-touch-device jw-is-no-mobile"
                                                                            data-jouwweb-segment-type="custom"
                                                data-template-threshold="960"
                                                data-template-name="concert-banner"
                            itemscope
        itemtype="https://schema.org/WebPage"
    >
                                    <meta itemprop="url" content="https://www.halal4u.es/www.webador.pl">
        <a href="/www.webador.pl#main-content" class="jw-skip-link">
            Ir al contenido principal        </a>
        <div class="jw-background"></div>
        <div class="jw-body">
            <div class="jw-mobile-menu jw-mobile-is-text js-mobile-menu">
            <button
            type="button"
            class="jw-mobile-menu__button jw-mobile-toggle"
            aria-label="Ocultar menú"
        >
            <span class="jw-icon-burger"></span>
        </button>
        <div class="jw-mobile-header jw-mobile-header--image-text">
        <a            class="jw-mobile-header-content"
                            href="/"
                        >
                            <img class="jw-mobile-logo jw-mobile-logo--square" src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/image-high-ambjw8.png?enable-io=true&amp;enable=upscale&amp;height=70" srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/image-high-ambjw8.png?enable-io=true&amp;enable=upscale&amp;height=70 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/image-high-ambjw8.png?enable-io=true&amp;enable=upscale&amp;height=140&amp;quality=70 2x" alt="Halal4u" title="Halal4u">                                        <div class="jw-mobile-text">
                    <span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"> <span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"> <span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"> <span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"> Halal4u </span></span> </span></span></span></span> </span></span></span></span></span> </span></span></span></span>                </div>
                    </a>
    </div>

        <a
        href="/cart"
        class="jw-mobile-menu__button jw-mobile-header-cart"
        aria-label="Ver carrito"
    >
        <span class="jw-icon-badge-wrapper">
            <span class="website-rendering-icon-basket" aria-hidden="true"></span>
            <span class="jw-icon-badge hidden" aria-hidden="true"></span>
        </span>
    </a>
    
    </div>
<header class="header-wrap js-topbar-content-container js-fixed-header-container">
    <div class="message-bar message-bar--accent"><div class="message-bar__container"><ul class="message-bar-usps"><li class="message-bar-usps__item"><i class="website-rendering-icon-ok"></i><span>FREE DELIVERY + 250€</span></li><li class="message-bar-usps__item"><i class="website-rendering-icon-ok"></i><span>ENVIO GRATIS + 250€</span></li><li class="message-bar-usps__item"><i class="website-rendering-icon-ok"></i><span></span></li></ul></div></div>    <div class="header-wrap__inner">
        <div class="header">
            <div class="jw-header-logo">
            <div
    id="jw-header-image-container"
    class="jw-header jw-header-image-container jw-header-image-toggle"
>
            <a href="/">
        <img id="jw-header-image" data-image-id="241280405" srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/image-high-ambjw8.png?enable-io=true&amp;width=100 100w, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/image-high-ambjw8.png?enable-io=true&amp;width=200 200w" class="jw-header-image" title="Halal4u" style="width: 100px;" sizes="100px" width="100" height="100" alt="Halal4u">                </a>
    </div>
        <div
    class="jw-header jw-header-title-container jw-header-text jw-header-text-toggle"
    data-stylable="true"
>
    <a        id="jw-header-title"
        class="jw-header-title"
                    href="/"
            >
        <span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"> <span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"> <span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"> <span style="display: inline-block; font-size: 30px;"><span style="display: inline-block; font-size: 30px;"> Halal4u </span></span> </span></span></span></span> </span></span></span></span></span> </span></span></span></span>    </a>
</div>
</div>
        </div>
        <nav class="menu jw-menu-copy">
            <ul
    id="jw-menu"
    class="jw-menu jw-menu-horizontal"
    >
            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/"                                    data-page-link-id="30127583"
                            >
                <span class="">
            Inicio        </span>
            </a>
                </li>
            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/store"                                    data-page-link-id="30131841"
                            >
                <span class="">
            STORE        </span>
            </a>
                </li>
            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/envio-y-devoluciones"                                    data-page-link-id="30128941"
                            >
                <span class="">
            Envío y Devoluciones        </span>
            </a>
                </li>
            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/contacto"                                    data-page-link-id="30127623"
                            >
                <span class="">
            Contacto        </span>
            </a>
                </li>
            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link jw-menu-link--icon"
        href="/account"                                                    title="Cuenta"
            >
                                <span class="website-rendering-icon-user"></span>
                            <span class="hidden-desktop-horizontal-menu">
            Cuenta        </span>
            </a>
                </li>
            <li
    class="jw-menu-item jw-menu-wishlist-item js-menu-wishlist-item jw-menu-wishlist-item--hidden"
>
        <a        class="jw-menu-link jw-menu-link--icon"
        href="/wishlist"                                                    title="Lista de deseos"
            >
                                    <span class="jw-icon-badge-wrapper">
                        <span class="website-rendering-icon-heart"></span>
                                            <span class="jw-icon-badge hidden">
                    0                </span>
                            <span class="hidden-desktop-horizontal-menu">
            Lista de deseos        </span>
            </a>
                </li>
            <li
    class="jw-menu-item js-menu-cart-item "
>
        <a        class="jw-menu-link jw-menu-link--icon"
        href="/cart"                                                    title="Carro de la compra"
            >
                                    <span class="jw-icon-badge-wrapper">
                        <span class="website-rendering-icon-basket"></span>
                                            <span class="jw-icon-badge hidden">
                    0                </span>
                            <span class="hidden-desktop-horizontal-menu">
            Carro de la compra        </span>
            </a>
                </li>
        </ul>
    <script nonce="bab73023f85443a8a59ed24af052cf0d" id="jw-mobile-menu-template" type="text/template">
        <ul id="jw-menu" class="jw-menu jw-menu-horizontal jw-menu-spacing--mobile-bar">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/"                                    data-page-link-id="30127583"
                            >
                <span class="">
            Inicio        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/store"                                    data-page-link-id="30131841"
                            >
                <span class="">
            STORE        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/envio-y-devoluciones"                                    data-page-link-id="30128941"
                            >
                <span class="">
            Envío y Devoluciones        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/contacto"                                    data-page-link-id="30127623"
                            >
                <span class="">
            Contacto        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link jw-menu-link--icon"
        href="/account"                                            >
                                <span class="website-rendering-icon-user"></span>
                            <span class="">
            Cuenta        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item jw-menu-wishlist-item js-menu-wishlist-item jw-menu-wishlist-item--hidden"
>
        <a        class="jw-menu-link jw-menu-link--icon"
        href="/wishlist"                                            >
                                    <span class="jw-icon-badge-wrapper">
                        <span class="website-rendering-icon-heart"></span>
                                            <span class="jw-icon-badge hidden">
                    0                </span>
                            <span class="">
            Lista de deseos        </span>
            </a>
                </li>
                                </ul>
    </script>
        </nav>
    </div>
</header>
<script nonce="bab73023f85443a8a59ed24af052cf0d">
    JOUWWEB.templateConfig = {
        header: {
            selector: '.header-wrap__inner',
            mobileSelector: '.jw-mobile-menu',
            updatePusher: function (topHeight) {
                var $sliderStyle = $('#sliderStyle');

                if ($sliderStyle.length === 0) {
                    $sliderStyle = $('<style />')
                        .attr('id', 'sliderStyle')
                        .appendTo(document.body);
                }

                // Header height without mobile bar
                var headerHeight = $('.header-wrap__inner').outerHeight();

                var paddingTop = topHeight;
                var paddingBottom = Math.min(headerHeight * (2/3), 60);
                $sliderStyle.html(
                    '.jw-slideshow-slide-content {' +
                    '    padding-top: ' + paddingTop + 'px;' +
                    '    padding-bottom: ' + paddingBottom + 'px;' +
                    '}' +
                    '.bx-controls-direction {' +
                    '    margin-top: ' + ((paddingTop - paddingBottom) / 2) + 'px;' +
                    '}'
                );

                // make sure slider also gets correct height (because of the added padding)
                $('.jw-slideshow-slide[aria-hidden=false]').each(function (index) {
                    var $this = $(this);
                    topHeight = $this.outerHeight() > topHeight ? $this.outerHeight() : topHeight;
                    $this.closest('.bx-viewport').css({
                        height: topHeight + 'px',
                    });
                });

                // If a page has a message-bar, offset the mobile nav.
                const $messageBar = $('.message-bar');
                if ($messageBar.length > 0) {
                    $('.js-mobile-menu, .jw-menu-clone').css('top', $messageBar.outerHeight());
                }
            },
        },
        mainContentOffset: function () {
            const $body = $('body');

            function measureAffixedHeaderHeight() {
                const $headerWrap = $('.header-wrap');
                const $headerWrapInner = $('.header-wrap__inner');

                // Early return if header is already affixed
                if ($body.hasClass('jw-is-header-affix')) {
                    return $headerWrap.height();
                }

                // Switch to affixed header (without transition)
                $headerWrapInner.css('transition', 'none');
                $body.addClass('jw-is-header-affix');

                // Measure affixed header height
                const headerHeight = $headerWrap.height();

                // Switch back to unaffixed header (without transition)
                $body.removeClass('jw-is-header-affix');
                $headerWrap.height(); // force reflow
                $headerWrapInner.css('transition', '');

                return headerHeight;
            }

            const headerHeight = measureAffixedHeaderHeight();
            return $('.main-content').offset().top - ($body.hasClass('jw-menu-is-mobile') ? 0 : headerHeight);
        },
    };
</script>
<div class="main-content">
    
<main id="main-content" class="block-content">
    <div data-section-name="content" class="jw-section jw-section-content jw-responsive">
        <div class="jw-strip jw-strip--default jw-strip--style-color jw-strip--primary jw-strip--color-default jw-strip--padding-both jw-strip--vertical-padding-default jw-strip--border-shape-none"><div class="jw-strip__background-container"><div class="jw-strip__background"></div></div><div class="jw-strip__content-container"><div class="jw-strip__content jw-responsive">
                        <h1>Página no encontrada</h1>
<p>
    Lo sentimos, no hemos podido encontrar esta página. Puede que ya no exista.</p>

</div></div></div>            </div>
</main>
    </div>
<footer class="block-footer">
    <div
        data-section-name="footer"
        class="jw-section jw-section-footer jw-responsive"
    >
                <div class="jw-strip jw-strip--default jw-strip--style-none jw-strip--primary jw-strip--padding-both jw-strip--vertical-padding-default jw-strip--border-shape-none"><div class="jw-strip__content-container"><div class="jw-strip__content jw-responsive">            <div class="jw-block-element"><div
    id="jw-element-550022414"
    data-jw-element-id="550022414"
        class="jw-tree-node jw-element jw-simple-root jw-tree-container jw-responsive jw-node-is-first-child jw-node-is-last-child"
>
    <div
    id="jw-element-770845424"
    data-jw-element-id="770845424"
        class="jw-tree-node jw-element jw-product jw-node-is-first-child"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:20454070,&quot;title&quot;:&quot;PEPPERONI HALAL FOR PIZZA 10 x 1 KG&quot;,&quot;url&quot;:&quot;\/product\/20454070\/pepperoni-halal-for-pizza-10-x-1-kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:74015406,&quot;stock&quot;:85,&quot;limited&quot;:true,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:187441652,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_4995-standard.png&quot;,&quot;width&quot;:800,&quot;height&quot;:800}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="20454070" data-jwlink-title="PEPPERONI HALAL FOR PIZZA 10 x 1 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20454070" href="/product/20454070/pepperoni-halal-for-pizza-10-x-1-kg">PEPPERONI HALAL FOR PIZZA 10 x 1 KG</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">135,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="20454070" data-jwlink-title="PEPPERONI HALAL FOR PIZZA 10 x 1 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20454070" href="/product/20454070/pepperoni-halal-for-pizza-10-x-1-kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4995-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4995-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4995-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>10 x 1 KG</p>
<p>BEEF+TURKEY PAVO-VACUNO PEPPERONI HALAL FOR PIZZA FROZEN-CONGELADO&nbsp;</p>
<p>&nbsp;</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="20454070" data-jwlink-title="PEPPERONI HALAL FOR PIZZA 10 x 1 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20454070" href="/product/20454070/pepperoni-halal-for-pizza-10-x-1-kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-562989549"
    data-jw-element-id="562989549"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:20454164,&quot;title&quot;:&quot;SALAMI HALAL 1 x 10 KG&quot;,&quot;url&quot;:&quot;\/product\/20454164\/salami-halal-1-x-10-kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:74015682,&quot;stock&quot;:99,&quot;limited&quot;:true,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:187443033,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_4996-standard.png&quot;,&quot;width&quot;:800,&quot;height&quot;:800}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="20454164" data-jwlink-title="SALAMI HALAL 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20454164" href="/product/20454164/salami-halal-1-x-10-kg">SALAMI HALAL 1 x 10 KG</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">135,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="20454164" data-jwlink-title="SALAMI HALAL 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20454164" href="/product/20454164/salami-halal-1-x-10-kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4996-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4996-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4996-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>BEEF+TURKEY PAVO-VACUNO SALAMI HALAL FOR PIZZA FROZEN-CONGELADO&nbsp;</p>
<p>&nbsp;</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="20454164" data-jwlink-title="SALAMI HALAL 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20454164" href="/product/20454164/salami-halal-1-x-10-kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-563074753"
    data-jw-element-id="563074753"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:20456066,&quot;title&quot;:&quot;FIAMBRE TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG&quot;,&quot;url&quot;:&quot;\/product\/20456066\/fiambre-turkey-pavo-halal-for-pizza-1-x-10-kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:74022315,&quot;stock&quot;:127,&quot;limited&quot;:true,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:187467453,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_4994-standard.png&quot;,&quot;width&quot;:800,&quot;height&quot;:800}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="20456066" data-jwlink-title="FIAMBRE TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20456066" href="/product/20456066/fiambre-turkey-pavo-halal-for-pizza-1-x-10-kg">FIAMBRE TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">125,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="20456066" data-jwlink-title="FIAMBRE TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20456066" href="/product/20456066/fiambre-turkey-pavo-halal-for-pizza-1-x-10-kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4994-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4994-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4994-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>10 x 1 KG<br />FIAMBRE TURKEY-PAVO HALAL FOR PIZZA FROZEN-CONGELADO&nbsp;</p>
<p>&nbsp;</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="20456066" data-jwlink-title="FIAMBRE TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20456066" href="/product/20456066/fiambre-turkey-pavo-halal-for-pizza-1-x-10-kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-563076315"
    data-jw-element-id="563076315"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:20456088,&quot;title&quot;:&quot;BACON TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG&quot;,&quot;url&quot;:&quot;\/product\/20456088\/bacon-turkey-pavo-halal-for-pizza-1-x-10-kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:74022339,&quot;stock&quot;:93,&quot;limited&quot;:true,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:187467767,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_4993-standard.png&quot;,&quot;width&quot;:800,&quot;height&quot;:800}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="20456088" data-jwlink-title="BACON TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20456088" href="/product/20456088/bacon-turkey-pavo-halal-for-pizza-1-x-10-kg">BACON TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">135,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="20456088" data-jwlink-title="BACON TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20456088" href="/product/20456088/bacon-turkey-pavo-halal-for-pizza-1-x-10-kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4993-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4993-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_4993-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>10 x 1 KG<br />BACON TURKEY-PAVO HALAL FOR PIZZA FROZEN-CONGELADO&nbsp;</p>
<p>&nbsp;</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="20456088" data-jwlink-title="BACON TURKEY-PAVO HALAL FOR PIZZA 1 x 10 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="20456088" href="/product/20456088/bacon-turkey-pavo-halal-for-pizza-1-x-10-kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-655940601"
    data-jw-element-id="655940601"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:22125696,&quot;title&quot;:&quot;HAMBURGUESA HALAL VACUNO-TERNERA BURGER MEAT 113GX48&quot;,&quot;url&quot;:&quot;\/product\/22125696\/hamburguesa-halal-vacuno-ternera-burger-meat-113gx48&quot;,&quot;variants&quot;:[{&quot;id&quot;:80593871,&quot;stock&quot;:0,&quot;limited&quot;:true,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:211384238,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/f601680f-711b-4a3a-bdb3-1026c5170670-standard.png&quot;,&quot;width&quot;:800,&quot;height&quot;:533}}"
>
    <header class="product__top">
        <div class="product-sticker product-sticker--sold-out">Agotado</div>        <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="22125696" data-jwlink-title="HAMBURGUESA HALAL VACUNO-TERNERA BURGER MEAT 113GX48" data-jwlink-readonly data-segment-type="product" data-segment-id="22125696" href="/product/22125696/hamburguesa-halal-vacuno-ternera-burger-meat-113gx48">HAMBURGUESA HALAL VACUNO-TERNERA BURGER MEAT 113GX48</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">47,30 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="22125696" data-jwlink-title="HAMBURGUESA HALAL VACUNO-TERNERA BURGER MEAT 113GX48" data-jwlink-readonly data-segment-type="product" data-segment-id="22125696" href="/product/22125696/hamburguesa-halal-vacuno-ternera-burger-meat-113gx48" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/f601680f-711b-4a3a-bdb3-1026c5170670-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/f601680f-711b-4a3a-bdb3-1026c5170670-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/f601680f-711b-4a3a-bdb3-1026c5170670-high.png?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>HAMBURGUESA HALAL VACUNO-TERNERA BURGER MEAT CAJA 113GX48 CONGELADO.</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="22125696" data-jwlink-title="HAMBURGUESA HALAL VACUNO-TERNERA BURGER MEAT 113GX48" data-jwlink-readonly data-segment-type="product" data-segment-id="22125696" href="/product/22125696/hamburguesa-halal-vacuno-ternera-burger-meat-113gx48">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Avisarme cuando esté disponible"
        >
    <span class="product__add-to-cart__label">Avisarme cuando esté disponible</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-mail"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-656106357"
    data-jw-element-id="656106357"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:22128210,&quot;title&quot;:&quot;HAMBURGUESA DE POLLO CRISPY HALAL 5 x 1 KG&quot;,&quot;url&quot;:&quot;\/product\/22128210\/hamburguesa-de-pollo-crispy-halal-5-x-1-kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:80600791,&quot;stock&quot;:0,&quot;limited&quot;:false,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:211411032,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_7536-standard.webp&quot;,&quot;width&quot;:800,&quot;height&quot;:565}}"
>
    <header class="product__top">
        <div class="product-sticker product-sticker--custom">NUEVO</div>        <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="22128210" data-jwlink-title="HAMBURGUESA DE POLLO CRISPY HALAL 5 x 1 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="22128210" href="/product/22128210/hamburguesa-de-pollo-crispy-halal-5-x-1-kg">HAMBURGUESA DE POLLO CRISPY HALAL 5 x 1 KG</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">40,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="22128210" data-jwlink-title="HAMBURGUESA DE POLLO CRISPY HALAL 5 x 1 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="22128210" href="/product/22128210/hamburguesa-de-pollo-crispy-halal-5-x-1-kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7536-high.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7536-high.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7536-high.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>HAMBURGUESA DE POLLO CRISPY HALAL 5 x 1 KG<br />CORNFLAKES CONGELADO (100G POR HAMBURGUESA)</p>
<p>&nbsp;</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="22128210" data-jwlink-title="HAMBURGUESA DE POLLO CRISPY HALAL 5 x 1 KG" data-jwlink-readonly data-segment-type="product" data-segment-id="22128210" href="/product/22128210/hamburguesa-de-pollo-crispy-halal-5-x-1-kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-770846203"
    data-jw-element-id="770846203"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:23958186,&quot;title&quot;:&quot;ALITAS POLLO TEX-M\u00c9X  HALAL (5x1KG)&quot;,&quot;url&quot;:&quot;\/product\/23958186\/alitas-pollo-tex-mex-halal-5x1kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:87332751,&quot;stock&quot;:0,&quot;limited&quot;:false,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:241275958,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_9319-standard-72ms7o.webp&quot;,&quot;width&quot;:800,&quot;height&quot;:565}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23958186" data-jwlink-title="ALITAS POLLO TEX-MÉX  HALAL (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958186" href="/product/23958186/alitas-pollo-tex-mex-halal-5x1kg">ALITAS POLLO TEX-MÉX  HALAL (5x1KG)</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">40,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="23958186" data-jwlink-title="ALITAS POLLO TEX-MÉX  HALAL (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958186" href="/product/23958186/alitas-pollo-tex-mex-halal-5x1kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_9319-high-ufffd0.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_9319-high-ufffd0.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_9319-high-ufffd0.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>Halal chicken wings tex-mex little spicy 5 x 1 kg</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23958186" data-jwlink-title="ALITAS POLLO TEX-MÉX  HALAL (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958186" href="/product/23958186/alitas-pollo-tex-mex-halal-5x1kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-770846450"
    data-jw-element-id="770846450"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:23958368,&quot;title&quot;:&quot;HALAL NUGGES POLLO (5x1KG)&quot;,&quot;url&quot;:&quot;\/product\/23958368\/halal-nugges-pollo-5x1kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:87333994,&quot;stock&quot;:0,&quot;limited&quot;:false,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:241278659,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_7531-standard-5l056y.webp&quot;,&quot;width&quot;:800,&quot;height&quot;:565}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23958368" data-jwlink-title="HALAL NUGGES POLLO (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958368" href="/product/23958368/halal-nugges-pollo-5x1kg">HALAL NUGGES POLLO (5x1KG)</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">35,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="23958368" data-jwlink-title="HALAL NUGGES POLLO (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958368" href="/product/23958368/halal-nugges-pollo-5x1kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7531-high-f6obcy.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7531-high-f6obcy.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7531-high-f6obcy.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>Halal chichen nugges cornflakes crispy 5 x 1 kg&nbsp;</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23958368" data-jwlink-title="HALAL NUGGES POLLO (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958368" href="/product/23958368/halal-nugges-pollo-5x1kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-770846925"
    data-jw-element-id="770846925"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:23958235,&quot;title&quot;:&quot;HALAL FINGERS POLLO AMERICAN CRISPY (5x1KG)&quot;,&quot;url&quot;:&quot;\/product\/23958235\/halal-fingers-pollo-american-crispy-5x1kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:87333184,&quot;stock&quot;:0,&quot;limited&quot;:false,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:241284797,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_7532-standard.webp&quot;,&quot;width&quot;:800,&quot;height&quot;:565}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23958235" data-jwlink-title="HALAL FINGERS POLLO AMERICAN CRISPY (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958235" href="/product/23958235/halal-fingers-pollo-american-crispy-5x1kg">HALAL FINGERS POLLO AMERICAN CRISPY (5x1KG)</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">48,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="23958235" data-jwlink-title="HALAL FINGERS POLLO AMERICAN CRISPY (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958235" href="/product/23958235/halal-fingers-pollo-american-crispy-5x1kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7532-high.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7532-high.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7532-high.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>American chicken crispy fingers halal 5 x 1 kg</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23958235" data-jwlink-title="HALAL FINGERS POLLO AMERICAN CRISPY (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958235" href="/product/23958235/halal-fingers-pollo-american-crispy-5x1kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-770847188"
    data-jw-element-id="770847188"
        class="jw-tree-node jw-element jw-product"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:23957701,&quot;title&quot;:&quot;CORD\u00d3N BLEU HALAL (5 x 1 KG)&quot;,&quot;url&quot;:&quot;\/product\/23957701\/cordon-bleu-halal-5-x-1-kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:87328649,&quot;stock&quot;:0,&quot;limited&quot;:false,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:241290212,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_0919-standard.jpg&quot;,&quot;width&quot;:245,&quot;height&quot;:189}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23957701" data-jwlink-title="CORDÓN BLEU HALAL (5 x 1 KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23957701" href="/product/23957701/cordon-bleu-halal-5-x-1-kg">CORDÓN BLEU HALAL (5 x 1 KG)</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">40,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="23957701" data-jwlink-title="CORDÓN BLEU HALAL (5 x 1 KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23957701" href="/product/23957701/cordon-bleu-halal-5-x-1-kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_0919-high.jpg?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_0919-high.jpg?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_0919-high.jpg?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>HALAL CORD&Oacute;N BLEU (5 x 1 KG)</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23957701" data-jwlink-title="CORDÓN BLEU HALAL (5 x 1 KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23957701" href="/product/23957701/cordon-bleu-halal-5-x-1-kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div><div
    id="jw-element-770847896"
    data-jw-element-id="770847896"
        class="jw-tree-node jw-element jw-product jw-node-is-last-child"
>
    <article
    class="product js-product-container product--style-simple"
    data-webshop-product="{&quot;id&quot;:23958368,&quot;title&quot;:&quot;HALAL NUGGES POLLO (5x1KG)&quot;,&quot;url&quot;:&quot;\/product\/23958368\/halal-nugges-pollo-5x1kg&quot;,&quot;variants&quot;:[{&quot;id&quot;:87333994,&quot;stock&quot;:0,&quot;limited&quot;:false,&quot;propertyValueIds&quot;:[]}],&quot;image&quot;:{&quot;id&quot;:241278659,&quot;url&quot;:&quot;https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/img_7531-standard-5l056y.webp&quot;,&quot;width&quot;:800,&quot;height&quot;:565}}"
>
    <header class="product__top">
                <h3 class="product__heading">
                            <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23958368" data-jwlink-title="HALAL NUGGES POLLO (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958368" href="/product/23958368/halal-nugges-pollo-5x1kg">HALAL NUGGES POLLO (5x1KG)</a>                    </h3>
                    <div>
                <div class="product-price js-product-container__price">
                    <span class="product-price__price">35,00 €</span>
                </div>
            </div>
            </header>
            <div
            class="product__image-container"
                        aria-hidden="true"
        >
            
            <a class="js-jouwweb-segment product-image" data-jwlink-type="product" data-jwlink-identifier="23958368" data-jwlink-title="HALAL NUGGES POLLO (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958368" href="/product/23958368/halal-nugges-pollo-5x1kg" tabindex="-1">                <img
                    class="product-image__image product-image__image--main"
                    loading="lazy"
                    src="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7531-high-f6obcy.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414"
                                        srcset="https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7531-high-f6obcy.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=414 1x, https://primary.jwwb.nl/public/t/d/d/temp-adxthpikjmolmfcoszxc/img_7531-high-f6obcy.webp?enable-io=true&amp;enable=upscale&amp;fit=bounds&amp;width=828 2x"
                    sizes="(min-width: 656px) 180px, (max-width: 656px) 100vw"
                    alt=""
                >
            </a>        </div>
                <div class="product__details">
                        <div
                class="product__description"
            >
                                <p>Halal chichen nugges cornflakes crispy 5 x 1 kg&nbsp;</p>            </div>
                                        <a class="js-jouwweb-segment" data-jwlink-type="product" data-jwlink-identifier="23958368" data-jwlink-title="HALAL NUGGES POLLO (5x1KG)" data-jwlink-readonly data-segment-type="product" data-segment-id="23958368" href="/product/23958368/halal-nugges-pollo-5x1kg">                Ver detalles<span class="website-rendering-icon-right-open"></span>
                </a>                    </div>
        <div class="product__button-container">
        <button
    type="button"
    class="jw-btn product__add-to-cart js-product-container__button jw-btn--size-medium"
    title="Añadir al carrito"
        >
    <span class="product__add-to-cart__label">Añadir al carrito</span>
            <span class="jw-btn-icon product__add-to-cart__icon website-rendering-icon-basket"></span>
    </button>
        
<button
    type="button"
    class="jw-btn jw-btn--icon-only product__add-to-wishlist js-product-container__wishlist-button jw-btn--size-medium"
    title="Añadir a la lista de deseos"
    aria-label="Añadir a la lista de deseos"
    >
    <span>
        <i class="js-product-container__add-to-wishlist_icon website-rendering-icon-heart-empty" aria-hidden="true"></i>
    </span>
</button>
            </div>
</article>

</div></div></div>                                        <div class="jw-block-footer-content">
                    <div class="jw-credits clear">
                        <div class="jw-credits-owner">
                            <div id="jw-footer-text">
                                <div class="jw-footer-text-content">
                                    &copy; 2025 - 2026 Halal4u                                </div>
                            </div>
                        </div>
                        <div class="jw-credits-right">
                                                        <div id="jw-credits-tool">
    <small>
        Con la tecnología de <a href="https://www.webador.es" rel="">Webador</a>    </small>
</div>
                        </div>
                    </div>
                </div>
                    </div></div></div>    </div>
</footer>
            
<div class="jw-bottom-bar__container">
    </div>
<div class="jw-bottom-bar__spacer">
    </div>

            <div id="jw-variable-loaded" style="display: none;"></div>
            <div id="jw-variable-values" style="display: none;">
                                    <span data-jw-variable-key="background-color" class="jw-variable-value-background-color"></span>
                                    <span data-jw-variable-key="background" class="jw-variable-value-background"></span>
                                    <span data-jw-variable-key="font-family" class="jw-variable-value-font-family"></span>
                                    <span data-jw-variable-key="paragraph-color" class="jw-variable-value-paragraph-color"></span>
                                    <span data-jw-variable-key="paragraph-link-color" class="jw-variable-value-paragraph-link-color"></span>
                                    <span data-jw-variable-key="paragraph-font-size" class="jw-variable-value-paragraph-font-size"></span>
                                    <span data-jw-variable-key="heading-color" class="jw-variable-value-heading-color"></span>
                                    <span data-jw-variable-key="heading-link-color" class="jw-variable-value-heading-link-color"></span>
                                    <span data-jw-variable-key="heading-font-size" class="jw-variable-value-heading-font-size"></span>
                                    <span data-jw-variable-key="heading-font-family" class="jw-variable-value-heading-font-family"></span>
                                    <span data-jw-variable-key="menu-text-color" class="jw-variable-value-menu-text-color"></span>
                                    <span data-jw-variable-key="menu-text-link-color" class="jw-variable-value-menu-text-link-color"></span>
                                    <span data-jw-variable-key="menu-text-font-size" class="jw-variable-value-menu-text-font-size"></span>
                                    <span data-jw-variable-key="menu-font-family" class="jw-variable-value-menu-font-family"></span>
                                    <span data-jw-variable-key="menu-capitalize" class="jw-variable-value-menu-capitalize"></span>
                                    <span data-jw-variable-key="website-size" class="jw-variable-value-website-size"></span>
                                    <span data-jw-variable-key="footer-text-color" class="jw-variable-value-footer-text-color"></span>
                                    <span data-jw-variable-key="footer-text-link-color" class="jw-variable-value-footer-text-link-color"></span>
                                    <span data-jw-variable-key="footer-text-font-size" class="jw-variable-value-footer-text-font-size"></span>
                                    <span data-jw-variable-key="content-color" class="jw-variable-value-content-color"></span>
                                    <span data-jw-variable-key="header-color" class="jw-variable-value-header-color"></span>
                                    <span data-jw-variable-key="accent-color" class="jw-variable-value-accent-color"></span>
                                    <span data-jw-variable-key="footer-color" class="jw-variable-value-footer-color"></span>
                                    <span data-jw-variable-key="menu-text-over-banner-color" class="jw-variable-value-menu-text-over-banner-color"></span>
                            </div>
        </div>
                            <script nonce="bab73023f85443a8a59ed24af052cf0d" type="application/ld+json">[{"@context":"https:\/\/schema.org","@type":"Organization","url":"https:\/\/www.halal4u.es\/","name":"Halal4u","logo":{"@type":"ImageObject","url":"https:\/\/primary.jwwb.nl\/public\/t\/d\/d\/temp-adxthpikjmolmfcoszxc\/image-high-ambjw8.png?enable-io=true&enable=upscale&height=60","width":60,"height":60},"email":"info@halal4u.es","telephone":"+34634432424"}]</script>
                <script nonce="bab73023f85443a8a59ed24af052cf0d">window.JOUWWEB = window.JOUWWEB || {}; window.JOUWWEB.experiment = {"enrollments":{},"defaults":{"only-annual-discount-restart":"3months-50pct","emphasize-strips-in-sidebar":"on","general-template-replacement":"on","ai-new-subpage-flow":"balanced","page-fill-explainer":"on","onboarding-banner-generation":"on","drip-mail-timings":"on","cycle-selector-layout":"listed","landing-overall-improvements":"on","homepage-strip-shapes":"after-banner","pagefill-text-emphasis":"on","onboarding-hide-structure-step":"second"}};</script>        <script nonce="bab73023f85443a8a59ed24af052cf0d">window.JOUWWEB.scripts.push("website-rendering/message-bar")</script>
<script nonce="bab73023f85443a8a59ed24af052cf0d">
            window.JOUWWEB = window.JOUWWEB || {};
            window.JOUWWEB.cookieConsent = {"theme":"jw","showLink":false,"content":{"message":"Esta P\u00e1gina web utiliza cookies para mejorar tu experiencia y mostrar anuncios personalizados. Al hacer clic en \"Aceptar\", aceptas el uso de todas las cookies.","allow":"Aceptar","deny":"Rechazar"},"type":"opt-in","autoOpen":true,"cookie":{"name":"cookieconsent_status"}};
        </script>
<script nonce="bab73023f85443a8a59ed24af052cf0d">window.plausible = window.plausible || function() { (window.plausible.q = window.plausible.q || []).push(arguments) };plausible('pageview', { props: {website: 6999929 }});</script>                                </body>
</html>
